// ==========================================
// 1. Store tasks in an array
// ==========================================

const tasks = [];


// ==========================================
// 2. Get HTML elements
// ==========================================

const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");
const stats = document.getElementById("stats");
const message = document.getElementById("message");


// ==========================================
// 3. Add a new task
// ==========================================

function addTask() {

    const text = taskInput.value.trim();

    // Do not add empty task
    if (text === "") {
        message.textContent = "Please enter a task.";
        return;
    }

    // Create task object
    const task = {
        text: text,
        done: false
    };

    // Add task to array
    tasks.push(task);

    // Clear input
    taskInput.value = "";

    // Clear error message
    message.textContent = "";

    // Show updated list
    render();
}


// ==========================================
// 4. Display tasks on the page
// ==========================================

function render() {

    // Clear old list
    taskList.innerHTML = "";

    // Loop through all tasks
    tasks.forEach((task, index) => {

        // Create list item
        const li = document.createElement("li");

        // Create task text
        const taskText = document.createElement("span");

        taskText.textContent = task.text;
        taskText.classList.add("task-text");

        // If task is done, add strike-through
        if (task.done) {
            taskText.classList.add("done");
        }


        // ==================================
        // Done button
        // ==================================

        const doneButton = document.createElement("button");

        doneButton.textContent = "Done";
        doneButton.classList.add("done-btn");

        doneButton.addEventListener("click", () => {

            // Toggle true/false
            task.done = !task.done;

            // Re-render list
            render();
        });


        // ==================================
        // Delete button
        // ==================================

        const deleteButton = document.createElement("button");

        deleteButton.textContent = "Delete";
        deleteButton.classList.add("delete-btn");

        deleteButton.addEventListener("click", () => {

            // Remove task from array
            tasks.splice(index, 1);

            // Re-render list
            render();
        });


        // ==================================
        // Add elements to list item
        // ==================================

        li.appendChild(taskText);
        li.appendChild(doneButton);
        li.appendChild(deleteButton);

        taskList.appendChild(li);
    });


    // ==================================
    // Update counter
    // ==================================

    const totalTasks = tasks.length;

    const remainingTasks = tasks.filter(
        task => !task.done
    ).length;

    stats.textContent =
        `Total tasks: ${totalTasks} | Remaining: ${remainingTasks}`;
}


// ==========================================
// 5. Add task when button is clicked
// ==========================================

addBtn.addEventListener("click", addTask);


// ==========================================
// 6. BONUS: Press Enter to add task
// ==========================================

taskInput.addEventListener("keydown", (event) => {

    if (event.key === "Enter") {
        addTask();
    }

});


// ==========================================
// 7. Initial display
// ==========================================

render();