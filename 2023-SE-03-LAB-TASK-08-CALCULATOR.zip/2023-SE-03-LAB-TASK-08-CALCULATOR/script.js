function calculateTip() {
  // Get values from input fields
  var bill = document.getElementById("bill").value;
  var tipPercent = document.getElementById("tipPercent").value;
  var people = document.getElementById("people").value;

  // Convert text values to numbers
  bill = Number(bill);
  tipPercent = Number(tipPercent);
  people = Number(people);

  // Basic check so we don't divide by zero
  if (people <= 0 || isNaN(people)) {
    people = 1;
  }

  // Calculate tip and total
  var tipAmount = (bill * tipPercent) / 100;
  var totalAmount = bill + tipAmount;
  var perPerson = totalAmount / people;

  // Show results on the page, rounded to 2 decimal places
  document.getElementById("tipAmount").innerHTML = tipAmount.toFixed(2);
  document.getElementById("totalAmount").innerHTML = totalAmount.toFixed(2);
  document.getElementById("perPerson").innerHTML = perPerson.toFixed(2);
}
