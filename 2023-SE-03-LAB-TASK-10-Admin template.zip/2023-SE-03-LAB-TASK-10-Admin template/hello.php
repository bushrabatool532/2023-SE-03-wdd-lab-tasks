 <!DOCTYPE html> <html> 
<head><title>Hello PHP</title></head
> <body> <h1>Hello from HTML</h1>
 <?php echo "<h2>Hello from PHP!</h2>"; echo "The time on the server is " . date("H:i:s"); ?>
 </body> </html>