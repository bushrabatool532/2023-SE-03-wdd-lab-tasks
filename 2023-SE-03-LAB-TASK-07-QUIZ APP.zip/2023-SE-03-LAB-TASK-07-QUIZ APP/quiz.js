// ----------------------------------
// QUIZ DATA
// ----------------------------------

const questions = [
  {
    q: "What does HTML stand for?",
    options: [
      "Hot Mail",
      "Hyper Text Markup Language",
      "How To Make Lasagna",
      "High Tech Modern Language"
    ],
    answer: 1
  },

  {
    q: "Which symbol is used for comments in JavaScript?",
    options: [
      "#",
      "//",
      "<!-- -->",
      "**"
    ],
    answer: 1
  },

  {
    q: "Which method adds an item to the end of an array?",
    options: [
      "push()",
      "pop()",
      "shift()",
      "add()"
    ],
    answer: 0
  },

  {
    q: "What does === check?",
    options: [
      "Value only",
      "Type only",
      "Value AND type",
      "Nothing"
    ],
    answer: 2
  },

  {
    q: "Which event fires when a user types in an input?",
    options: [
      "click",
      "submit",
      "input",
      "hover"
    ],
    answer: 2
  }
];


// ----------------------------------
// APP STATE
// ----------------------------------

let currentIndex = 0;
let score = 0;


// ----------------------------------
// DOM REFERENCES
// ----------------------------------

const questionEl = document.getElementById("question");

const optionsEl = document.getElementById("options");

const nextBtn = document.getElementById("nextBtn");

const progressEl = document.getElementById("progress");


// ----------------------------------
// SHOW CURRENT QUESTION
// ----------------------------------

function showQuestion() {

  const q = questions[currentIndex];

  progressEl.textContent =
    `Question ${currentIndex + 1} of ${questions.length}`;

  questionEl.textContent = q.q;

  optionsEl.innerHTML = "";

  q.options.forEach((opt, i) => {

    const label = document.createElement("label");

    label.innerHTML = `
      <input type="radio" name="opt" value="${i}">
      ${opt}
    `;

    optionsEl.appendChild(label);

  });

  nextBtn.disabled = true;

  nextBtn.textContent =
    (currentIndex === questions.length - 1)
      ? "Finish"
      : "Next";
}


// ----------------------------------
// ENABLE NEXT BUTTON
// WHEN OPTION IS SELECTED
// ----------------------------------

optionsEl.addEventListener("change", () => {

  nextBtn.disabled = false;

});


// ----------------------------------
// NEXT BUTTON
// ----------------------------------

nextBtn.addEventListener("click", () => {

  const picked =
    document.querySelector('input[name="opt"]:checked');

  if (!picked) {
    return;
  }

  // Check answer
  if (
    Number(picked.value) ===
    questions[currentIndex].answer
  ) {
    score++;
  }

  currentIndex++;

  if (currentIndex < questions.length) {

    showQuestion();

  } else {

    showResult();

  }

});


// ----------------------------------
// SHOW FINAL RESULT
// ----------------------------------

function showResult() {

  progressEl.textContent = "";

  questionEl.textContent =
    `You got ${score} out of ${questions.length}`;

  optionsEl.innerHTML = "";

  nextBtn.textContent = "Restart";

  nextBtn.disabled = false;

  nextBtn.onclick = () => {

    currentIndex = 0;

    score = 0;

    nextBtn.onclick = null;

    showQuestion();

  };

}


// ----------------------------------
// ENTER KEY
// ----------------------------------

document.addEventListener("keydown", (e) => {

  if (e.key === "Enter" && !nextBtn.disabled) {

    nextBtn.click();

  }

});


// ----------------------------------
// START QUIZ
// ----------------------------------

showQuestion();