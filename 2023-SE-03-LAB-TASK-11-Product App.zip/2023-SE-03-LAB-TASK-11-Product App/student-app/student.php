<?php require "db.php";
 $sql = "SELECT id, name, roll_number, course, semester, gpa FROM students";
  $result = mysqli_query($conn, $sql);
   if (!$result) { die("Query failed: " . mysqli_error($conn)); } $total = mysqli_num_rows($result); ?>
    <!DOCTYPE html> <html>
         <head><title>Student Records</title></head> 
         <body> <h2>All Students</h2> <p><?= $total ?> students in total</p> <a href="new-student.php">+ Add new student</a> 
         <table border="1" cellpadding="6" cellspacing="0"> 
            <tr> <th>ID</th> <th>Name</th> <th>Roll Number</th> <th>Course</th> <th>Semester</th> <th>GPA</th> </tr>
             <?php while ($row = mysqli_fetch_assoc($result)) { ?> <tr> <td><?= $row["id"] ?></td> <td><?= htmlspecialchars($row["name"]) ?></td> <td><?= htmlspecialchars($row["roll_number"]) ?></td> <td><?= htmlspecialchars($row["course"]) ?></td> <td><?= $row["semester"] ?></td> <td><?= $row["gpa"] ?></td> </tr> <?php } ?>
             </table> 
            </body> </html>