<?php require "db.php";
 $message = ""; 
 if ($_SERVER["REQUEST_METHOD"] === "POST") { $name = $_POST["name"]; 
 $roll_number = $_POST["roll_number"];
  $course = $_POST["course"];
   $semester = $_POST["semester"]; 
   $gpa = $_POST["gpa"]; 
   $name = mysqli_real_escape_string($conn, $name);
    $roll_number = mysqli_real_escape_string($conn, $roll_number); 
    $course = mysqli_real_escape_string($conn, $course);
     $semester = (int) $semester;
      $gpa = (float) $gpa;
       $sql = "INSERT INTO students (name, roll_number, course, semester, gpa) VALUES ('$name', '$roll_number', '$course', $semester, $gpa)";
        if (mysqli_query($conn, $sql)) { header("Location: students.php"); 
        exit; } else { $message = "Error: " . mysqli_error($conn); } } ?> 
        <!DOCTYPE html> <html>
             <head><title>Add Student</title></head> 
             <body> 
                <h2>Add a new student</h2>
                 <?php if ($message) { ?> <p style="color:red;"><?= $message ?></p> <?php } ?> 
                 <form method="POST" action="new-student.php">
                     <p>Name: <input type="text" name="name" required></p> 
                     <p>Roll Number: <input type="text" name="roll_number" required></p> 
                     <p>Course: <input type="text" name="course" required></p>
                      <p>Semester: <input type="number" name="semester" required></p>
                       <p>GPA: <input type="number" name="gpa" step="0.01" required></p>
                        <button>Save student</button> </form> <p><a href="students.php">← Back to list</a></p>
                     </body>
                      </html>