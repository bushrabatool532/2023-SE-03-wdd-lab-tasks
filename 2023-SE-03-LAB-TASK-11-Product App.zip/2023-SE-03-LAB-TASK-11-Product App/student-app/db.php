 <?php $host = "localhost"; 
 $user = "root";
  $pass = "";
   $name = "inventorydb";
    $conn = mysqli_connect($host, $user, $pass, $name);
     if (!$conn) { die("Connection failed: " . mysqli_connect_error()); } ?>